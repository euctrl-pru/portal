# make initial cri dataset
data_import <- function(ast_data, static_data) {
  # read flighthour and occurrence per Entity 
  ast <- read_csv(paste0(ast_data)) 
  
  # weight and ectrl data
  sheets <- readxl::excel_sheets(paste0(static_data))
  dt <- map(sheets, read_excel, path = paste0(static_data))
  
  dt[[3]] <- ast 
  dt
}

# calculate cri indicators
calculate_indicators <- function(safety_data) {
  
  # weight data
  weights <- safety_data[[1]] %>% mutate(jn = 1)
  
  # cri data
  cri <- safety_data[[3]]
    
  # EUROCONTROL averages
  ectl_vals <- safety_data[[2]]
  
  # read data
  cri1 <- cri %>%
    # rename total number of occurrences
    mutate(
      occs_all = total_number_of_all_reported_occurrences,
      tech_all = total_no_of_tech_occurrences,
      ops_all = total_no_of_ops_occurrences,
      jn = 1
    ) %>%
    # calculte the sum of the groups SMI, UPA and RI
    mutate(
      ri_all = rowSums(select(., contains("ri_"))),
      smi_all = rowSums(select(., contains("smi"))),
      upa_all = rowSums(select(., contains("upa")))
    ) %>%
    # calculate number of Other OPS incidents
    mutate(
      ops_without_others = ri_all + smi_all + upa_all,
      ops_other = ops_all - ops_without_others
    ) %>%
    select(-c(ops_without_others)) %>%
    # calculate sum per event type, for all years
    group_by() %>%
    mutate(
      occs_all_years = sum(occs_all),
      ri_all_years = sum(ri_all),
      smi_all_years = sum(smi_all),
      upa_all_years = sum(upa_all),
      tech_all_years = sum(tech_all),
      ops_all_years = sum(ops_all)
    ) %>%
    ungroup() %>% 
    # join weights on CRI data
    left_join(weights, by = c("jn")) %>% 
    # calculate estimates
    mutate(
      # accidents
      # note: no grade D incidents probabilities are added 
      acc_est = accident,
      # incidents: runway incursions
      # note: only RI grade D incidents probabilities are added 
      ri_a_est = calc_est(ri_a, ri_all_years, ri_d),
      ri_b_est = calc_est(ri_b, ri_all_years, ri_d),
      ri_c_est = calc_est(ri_c, ri_all_years, ri_d),
      # incidents: separation minima infringements
      # note: only SMI grade D incidents probabilities are added 
      smi_a_est = calc_est(smi_a, smi_all_years, smi_d),
      smi_b_est = calc_est(smi_b, smi_all_years, smi_d),
      smi_c_est = calc_est(smi_c, smi_all_years, smi_d), 
      # incidents: unauthorised penetration of airspace
      # note: only UPA grade D incidents probabilities are added 
      upa_a_est = calc_est(upa_a, upa_all_years, upa_d),
      upa_b_est = calc_est(upa_b, upa_all_years, upa_d),
      upa_c_est = calc_est(upa_c, upa_all_years, upa_d),
      # other ops incidents
      # note: all OPS grade D incidents probabilities are added 
      ops_other_est = ops_other,
      # tech incidents
      # note: only TECH grade D incidents probabilities are added 
      t_aa_est = calc_est(t_aa, occs_all_years, t_d),
      t_a_est = calc_est(t_a, occs_all_years, t_d),
      t_b_est = calc_est(t_b, occs_all_years, t_d),
      t_c_est = calc_est(t_c, occs_all_years, t_d)
    ) %>% 
    # calcualte CRI
    mutate(
      # accidents
      # note: no grade D incidents probabilities are added 
      acc_est_cri = acc_est * w_acc,
      # incidents: runway incursions
      # note: only RI grade D incidents probabilities are added 
      ri_a_est_cri = ri_a_est * w_ops_ri_a,
      ri_b_est_cri = ri_b_est * w_ops_ri_b,
      ri_c_est_cri = ri_c_est * w_ops_ri_c,
      # incidents: separation minima infringements
      # note: only SMI grade D incidents probabilities are added 
      smi_a_est_cri = smi_a_est * w_ops_smi_a,
      smi_b_est_cri = smi_b_est * w_ops_smi_b,
      smi_c_est_cri = smi_c_est * w_ops_smi_c, 
      # incidents: unauthorised penetration of airspace
      # note: only UPA grade D incidents probabilities are added 
      upa_a_est_cri = upa_a_est * w_ops_upa_a,
      upa_b_est_cri = upa_b_est * w_ops_upa_b,
      upa_c_est_cri = upa_c_est * w_ops_upa_c,
      # other ops incidents
      # note: all OPS grade D incidents probabilities are added 
      ops_other_est_cri = ops_other_est * w_ops_other,
      # tech incidents
      # note: only TECH grade D incidents probabilities are added 
      t_aa_est_cri = t_aa_est * w_tech_aa,
      t_a_est_cri = t_a_est * w_tech_a,
      t_b_est_cri = t_b_est * w_tech_b,
      t_c_est_cri = t_c_est * w_tech_c,
      # summing per groups
      ri_cri = ri_a_est_cri + ri_b_est_cri + ri_c_est_cri,
      smi_cri = smi_a_est_cri + smi_b_est_cri + smi_c_est_cri,
      upa_cri = upa_a_est_cri + upa_b_est_cri + upa_c_est_cri,
      ops_cri = ri_cri + smi_cri + upa_cri, 
      tech_cri = t_aa_est_cri + t_a_est_cri + t_b_est_cri + t_c_est_cri,
      acc_cri = acc_est_cri,
      ops_other_cri = ops_other_est_cri,
      # calculate CRI
      cri = (acc_cri + ops_cri + ops_other_cri + tech_cri),
      # calculate normalized CRI
      cri_n_occ = (cri / occs_all),
      cri_n_occ_flhr = (cri_n_occ / flight_hours) * 10^6,
      # cri indices values normalised (no. occurrences)
      ri_cri_n_occ = (ri_cri / occs_all),
      smi_cri_n_occ = (smi_cri / occs_all),
      upa_cri_n_occ = (upa_cri / occs_all),
      tech_cri_n_occ = (tech_cri / occs_all),
      # cri indices values normalised(no. flight and no. occurrences)
      ri_cri_n_occ_flhr = (ri_cri_n_occ / flight_hours) * 10^6,
      smi_cri_n_occ_flhr = (smi_cri_n_occ / flight_hours) * 10^6,
      upa_cri_n_occ_flhr = (upa_cri_n_occ / flight_hours) * 10^6,
      tech_cri_n_occ_flhr = (tech_cri_n_occ / flight_hours) * 10^6
    ) %>% 
    # select useful columns
    select(year, Entity, configuration, flight_hours, 
           # cri indices
           cri, acc_cri, ri_cri, smi_cri, upa_cri, ops_cri, tech_cri, ops_other_cri,
           # number of occurrences
           accident, ri_all, smi_all, upa_all, ops_all, tech_all, occs_all, 
           ops_other, 
           # cri indices normalized per no. occurrences
           ri_cri_n_occ, smi_cri_n_occ, upa_cri_n_occ, tech_cri_n_occ, 
           cri_n_occ, 
           # cri indices normalized per no. occurrences and flight hours
           ri_cri_n_occ_flhr, smi_cri_n_occ_flhr, upa_cri_n_occ_flhr, 
           tech_cri_n_occ_flhr, cri_n_occ_flhr)    

  # merge data
  bind_rows(cri1, ectl_vals) %>% 
    mutate(to_highlight = ifelse(Entity == "ECTL all MS", "ECTL all MS", "User data"))
}

# calculate estimated values of occurrences for selection of best Weight Combo
calc_est <- function(event, all_events, not_det = 0) {
  # probability of occurrence
  p_event <- event / all_events
  p_event <- ifelse(p_event == "NaN", 0, p_event)
  # estimated not-determined events according to probability of occurrence
  p_event_nt <- p_event * not_det
  p_event_nt <- ifelse(p_event == "NaN", 0, p_event_nt)
  # calculate the estimate per group per Entity
  (event + p_event_nt) 
}

# ploting function
plot_indicator <- function(data, my_year, Pri_x, Pri_y, Sec_y, 
                           highl, Pri_y_name, Sec_y_name, 
                           Title = "") {
  if (Pri_y == "cri_n_occ") {
    data <- data
  } else {
    data <- data %>% filter(Entity != "ECTL all MS")
  }
  
  # initial filtering
  df <- data %>% filter(year %in% my_year)
  
  plot_limits <- c(min(df[,Pri_y]), max(df[,Pri_y]))
  
  # fix the scale of the second axis
  y1_over_y2 <- max(df[,Pri_y], na.rm = T) / max(df[,Sec_y], na.rm = T)
  
  # plotting
  ggplot(df) +
    geom_col(aes(x = reorder(!!sym(Pri_x), -!!sym(Pri_y)), y = !!sym(Pri_y), fill = !!sym(highl)),
                 color = "black", alpha = 0.7, width = 0.85) +
    geom_point(aes(x = reorder(!!sym(Pri_x), -!!sym(Sec_y)), y = (!!sym(Sec_y)) * y1_over_y2),
               size = 4, color = "dark red", alpha = 0.8) +
    scale_y_continuous(sec.axis = sec_axis(~. / y1_over_y2, name = Sec_y_name)) +
    #facet_wrap(~ year) +
    scale_fill_manual(values = c("ECTL all MS" = "tomato", "User data" = "#4f81bd"), guide = FALSE) +
    theme(axis.line.x = element_line(color="black", size = 0.5),
          axis.line.y = element_line(color="black", size = 0.5), 
                                     axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.4), 
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.border = element_blank(),
          panel.background = element_rect(fill = "white", colour = NA)) +
    labs(x = "", y = Pri_y_name, title = Title)
}

# violin ploting function
violin_plot <- function(data, Pri_x, Pri_y, Sec_y, 
                        highl, Pri_y_name, Sec_y_name, 
                        Title = "") {
  if (Pri_y == "cri_n_occ") {
    df <- data
  } else {
    df <- data %>% filter(Entity != "ECTL all MS")
  }
  
  df <- df %>% mutate(year = as.factor(year))
  
  plot_limits <- c(min(df[,Pri_y]), max(df[,Pri_y]))
  
  # fix the scale of the second axis
  y1_over_y2 <- max(df[,Pri_y], na.rm = T) / max(df[,Sec_y], na.rm = T)
  
  dodge <- position_dodge(width = 0.4)
  
  # plotting
  ggplot(df, aes(x = !!sym(Pri_x), y = !!sym(Pri_y))) +
    geom_violin(aes(fill = year), color = "darkblue", alpha = 0.7, position = dodge, adjust = 0.5) +
    geom_boxplot(width=0.1) +  
    #geom_point(aes(x = reorder(!!sym(Pri_x), -!!sym(Sec_y)), y = (!!sym(Sec_y)) * y1_over_y2),
    #           size = 3, color = "dark blue", alpha = 0.4) +
    #scale_y_continuous(sec.axis = sec_axis(~. / y1_over_y2, name = Sec_y_name)) +
    #scale_fill_manual(values = c("ECTL all MS" = "tomato", "User data" = "lightblue"), guide = FALSE) +
    theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.4),
          legend.position = "bottom") +
    theme_minimal() +
    labs(x = "", y = Pri_y_name, title = Title)
}


# interactive plot for cri_n_occ 
interactive_plot <- function(data) {
  cri_test <- data %>% 
    mutate(year = as.factor(year))
  
  df <- SharedData$new(cri_test)
  widgets <- bscols(
    widths = c(12, 12, 12),
    filter_select("year", "Year", df, ~ year)
  )
  
  bscols(widths = c(4, 8), 
         widgets, 
         plot_ly(df, x = ~ Entity, y = ~ cri_n_occ, color = ~year, showlegend = FALSE) %>% 
           add_bars())
}

# interactive plot all indicators (except cri_n_occ) - no ectl avg value
interactive_plot_all <- function(data) {
  cri_test <- data %>% 
    filter(Entity != "ECTL all MS") %>% 
    tidyr::gather(
      `cri`, `acc_cri`, `ri_cri`, `smi_cri`, `upa_cri`, `ops_cri`, `tech_cri`,
      `ri_cri_n_occ`, `smi_cri_n_occ`, `upa_cri_n_occ`, `tech_cri_n_occ`,
      `cri_n_occ`, `ri_cri_n_occ_flhr`, `smi_cri_n_occ_flhr`,  
      `upa_cri_n_occ_flhr`, `tech_cri_n_occ_flhr`, `cri_n_occ_flhr`,
      key = "index_type", value = "cases") %>% 
    filter(!index_type %in% c("cri_n_occ")) %>% 
    mutate(year = as.factor(year))
  
  df <- SharedData$new(cri_test)
  widgets <- bscols(
    widths = c(12, 12, 12),
    filter_select("index_type", "Index type: ", df, ~ index_type),
    filter_select("year", "Year", df, ~ year)
  )
  
  bscols(widths = c(4, 8), 
         widgets, 
         plot_ly(df, x = ~ Entity, y = ~ cases, color = ~year, showlegend = FALSE) %>% 
           add_bars())
}

# transform safety data from short to long format
data_transform <- function(data) {
 data %>%
    tidyr::gather(
      `cri`,
      `acc_cri`,
      `ri_cri`,
      `smi_cri`,
      `upa_cri`,
      `ops_cri`,
      `tech_cri`,
      `ops_other_cri`,
      `accident`,
      `ri_cri_n_occ`,
      `smi_cri_n_occ`,
      `upa_cri_n_occ`,
      `tech_cri_n_occ`,
      `cri_n_occ`,
      `ri_cri_n_occ_flhr`,
      `smi_cri_n_occ_flhr`,
      `upa_cri_n_occ_flhr`,
      `tech_cri_n_occ_flhr`,
      `cri_n_occ_flhr`,
      key = "Indicator",
      value = "Value"
    ) 
}