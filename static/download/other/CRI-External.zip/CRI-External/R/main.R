# Script for Visualisation of CRI results - for EXTERNAL use

library(ggplot2)
library(readxl)
library(dplyr)
library(purrr)
library(gridExtra)
library(grid)
library(readr)
library(tidyr)
library(ggthemes)
library(crosstalk)
library(plotly)

source("R/functions.R")

# 1. Data import
safety_data <- data_import(
  "data/sample_data/astdata_sample.csv",         # User Data (safety data)
  "data/processed_data/ectrl_data.xlsx"          # EUROCONTROL average values + weights data
) 

# 2. Calculate indicators
cri <- calculate_indicators(safety_data) 

# 3. violin plot
violin_plot(
  data = cri,                                   # your dataset
  Pri_x = "year",                               # specify primary x axis
  Pri_y = "cri_n_occ_flhr",                     # specify primary y axis
  Sec_y = "occs_all",                           # specify secondary y axis
  highl = "to_highlight",                       # specify column used for color
  Pri_y_name = "CRI normalised by flight hours",# name of primary y axis
  Sec_y_name = "Total number of occurrences"    # name of secondary y axis
)

# 4. CRI histogram
plot_indicator(
  data = cri,                                   # your dataset
  my_year = 2017,                               # specify the year for the filter
  Pri_x = "Entity",                             # specify primary x axis
  Pri_y = "cri",                                # specify primary y axis
  Sec_y = "occs_all",                           # specify secondary y axis
  highl = "to_highlight",                       # specify column used for color
  Pri_y_name = "CRI",                           # name of primary y axis
  Sec_y_name = "Total number of occurrences",   # name of secondary y axis
  Title = "Composite Risk Index (2017)"         # specify the plot title (optional)
)

# 5. CRI normalised per no occurrences
plot_indicator(
  data = cri,                                   # your dataset
  my_year = 2017,                               # specify the year for the filter
  Pri_x = "Entity",                             # specify primary x axis
  Pri_y = "cri_n_occ",                          # specify primary y axis
  Sec_y = "occs_all",                           # specify secondary y axis
  highl = "to_highlight",                       # specify column used for color
  Pri_y_name = "CRI",                           # name of primary y axis
  Sec_y_name = "Total number of occurrences",   # name of secondary y axis
  Title = "Composite Risk Index (2017)"         # specify the plot title (optional)
)

# 6. CRI normalised per no occurrences and flight hours - Y axis flt hours
plot_indicator(
  data = cri,                                   # your dataset
  my_year = 2017,                               # specify the year for the filter
  Pri_x = "Entity",                             # specify primary x axis
  Pri_y = "cri_n_occ_flhr",                     # specify primary y axis
  Sec_y = "flight_hours",                       # specify secondary y axis
  highl = "to_highlight",                       # specify column used for color
  Pri_y_name = "CRI normalised by flight hours",# name of primary y axis
  Sec_y_name = "Total number of flight hours",  # name of secondary y axis
  Title = "Composite Risk Index normalised by flight hours (2017)"         # specify the plot title (optional)
)

# 7. CRI normalised per no occurrences and flight hours Y axis total no occurrences
plot_indicator(
  data = cri,                                   # your dataset
  my_year = 2017,                               # specify the year for the filter
  Pri_x = "Entity",                             # specify primary x axis
  Pri_y = "cri_n_occ_flhr",                     # specify primary y axis
  Sec_y = "occs_all",                           # specify secondary y axis
  highl = "to_highlight",                       # specify column used for color
  Pri_y_name = "CRI normalised by flight hours",# name of primary y axis
  Sec_y_name = "Total number of occurrences",   # name of secondary y axis
  Title = "Composite Risk Index normalised by flight hours (2017)"         # specify the plot title (optional)
)

# 8. Boxplot of all Sattes and all years - X axis = States
ggplot(cri, aes(x = reorder(Entity,cri_n_occ), y = cri_n_occ)) +
  
  geom_boxplot(fill = "white", colour = "#4f81bd") +
  
  #scale_fill_manual(values = c("ECTL all MS" = "tomato", "User data" = "#4f81bd"), guide = "none") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5)) +
  #theme_minimal() +
  labs(x = "Member States", y = "CRI", title = "BoxPlot of CRI values for all States 2015-2017")


