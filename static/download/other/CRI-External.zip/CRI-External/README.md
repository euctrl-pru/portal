---
output:
  pdf_document: default
  html_document: default
---
# Composite Risk Index - User Guide

These instructions will get the project up and running on your local machine for development and testing purposes. 

In order to calculate composite risk, please follow the steps below.

## Prerequisites
User need to have R (https://cran.r-project.org/) and RStudio (https://www.rstudio.com/) installed on their machine in order to run CRI application.

## Open CRI project
Open 'CRI-external.Rproj' file in RStudio. 

## User data
To run CRI calculation it is necessary to (prepare) and load User's safety occurrence data and pre-calculated EUROCONTROL average values.

Sample data is available to test the methodology and it can be found at **"data/sample_data/"** folder. 

Please feel free to use this data as input to get familiar with the methodology.

If you want to run analysis and calculation of CRI based on you own data, please use the empty template provided in **"data/sample_data/"** folder (**safety_data_template.csv**) and populate it with your values. 

Please make sure that you do not change the names of the columns!

## CRI methodology test 
In RStudio open 'CRI_methodology_external.Rmd' file. 

Run / knit this Rmarkdown file to automatically get the output of data analysis in html file format 'CRI_methodology_external.html'.

For advanced users: In case you want further to customise your analysis and visualisation of results the script and all the necesasry functions can be found at **"/R/"** folder.

## Authors

**EUROCONTROL Performance Review Unit**

## License

This project is open source.



